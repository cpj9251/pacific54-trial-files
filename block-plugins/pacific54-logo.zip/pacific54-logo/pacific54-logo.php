<?php
/**
 * Plugin Name:       Pacific 54 Logo
 * Description:       This block outputs logo used in pacific 54 demo test.
 * Requires at least: 6.1
 * Requires PHP:      7.0
 * Version:           0.1.0
 * Author:            Paul Jarvis
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       pacific54-logo
 *
 * @package           pacific54-logo
 */

/**
 * Registers the block using the metadata loaded from the `block.json` file.
 * Behind the scenes, it registers also all assets so they can be enqueued
 * through the block editor in the corresponding context.
 *
 * @see https://developer.wordpress.org/reference/functions/register_block_type/
 */
function pacific54_logo_pacific54_logo_block_init() {
	register_block_type( __DIR__ . '/build' );
}
add_action( 'init', 'pacific54_logo_pacific54_logo_block_init' );
