<?php
/**
 * Title: Pacific 54 Services Block
 * Slug: pacific54/pac-services-block
 * Categories: featured
 */
?>


<!-- wp:columns {"style":{"spacing":{"padding":{"left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns" style="padding-right:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--50)"><!-- wp:column {"className":"col-lg-4 col-md-6 wow zoomIn"} -->
<div class="wp-block-column col-lg-4 col-md-6 wow zoomIn"><!-- wp:pac-inner/pac-inner {"className":"inner-block-white-bg text-center service-item d-flex flex-column justify-content-center text-center rounded"} -->
<div class="wp-block-pac-inner-pac-inner inner-block-white-bg text-center service-item d-flex flex-column justify-content-center rounded"><!-- wp:html -->
<div class="service-icon flex-shrink-0">
          <i class="fa fa-home fa-2x"></i>
          </div>
<!-- /wp:html -->

<!-- wp:heading {"textAlign":"center","level":5,"style":{"typography":{"textTransform":"capitalize","fontStyle":"normal","fontWeight":"700"}},"className":"mb-3"} -->
<h5 class="wp-block-heading has-text-align-center mb-3" style="font-style:normal;font-weight:700;text-transform:capitalize">SEO Optimization</h5>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"padding":{"top":"0","right":"var:preset|spacing|30","bottom":"0","left":"var:preset|spacing|30"}}}} -->
<p class="has-text-align-center" style="padding-top:0;padding-right:var(--wp--preset--spacing--30);padding-bottom:0;padding-left:var(--wp--preset--spacing--30)">Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem sed diam stet diam sed stet lorem. <br><a class="btn px-3 mt-auto mx-auto" href="">Read More</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:pac-inner/pac-inner --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"inner-block-white-bg text-center service-item d-flex flex-column justify-content-center text-center rounded"} -->
<div class="wp-block-column inner-block-white-bg text-center service-item d-flex flex-column justify-content-center rounded"><!-- wp:pac-inner/pac-inner {"className":"inner-block-white-bg text-center service-item d-flex flex-column justify-content-center text-center rounded"} -->
<div class="wp-block-pac-inner-pac-inner inner-block-white-bg text-center service-item d-flex flex-column justify-content-center rounded"><!-- wp:html -->
<div class="service-icon flex-shrink-0">
          <i class="fa fa-home fa-2x"></i>
          </div>
<!-- /wp:html -->

<!-- wp:heading {"level":5,"style":{"typography":{"textTransform":"capitalize"}},"className":"mb-3"} -->
<h5 class="wp-block-heading mb-3" style="text-transform:capitalize">Web Design</h5>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"spacing":{"padding":{"left":"var:preset|spacing|30","right":"var:preset|spacing|30"}}}} -->
<p style="padding-right:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--30)">Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem sed diam stet diam sed stet lorem.<br><a class="btn px-3 mt-auto mx-auto" href="">Read More</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:pac-inner/pac-inner --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"col-lg-4 col-md-6 wow zoomIn text-center"} -->
<div class="wp-block-column col-lg-4 col-md-6 wow zoomIn text-center"><!-- wp:pac-inner/pac-inner {"className":"inner-block-white-bg text-center service-item d-flex flex-column justify-content-center text-center rounded"} -->
<div class="wp-block-pac-inner-pac-inner inner-block-white-bg text-center service-item d-flex flex-column justify-content-center rounded"><!-- wp:html -->
<div class="service-icon flex-shrink-0">
          <i class="fa fa-home fa-2x"></i>
          </div>
<!-- /wp:html -->

<!-- wp:heading {"level":5,"style":{"typography":{"textTransform":"capitalize"}},"className":"mb-3"} -->
<h5 class="wp-block-heading mb-3" style="text-transform:capitalize">Social Media Marketing</h5>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"padding":{"top":"0","right":"var:preset|spacing|30","bottom":"0","left":"var:preset|spacing|30"}}}} -->
<p class="has-text-align-center" style="padding-top:0;padding-right:var(--wp--preset--spacing--30);padding-bottom:0;padding-left:var(--wp--preset--spacing--30)">Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem sed diam stet diam sed stet lorem.<br><a class="btn px-3 mt-auto mx-auto" href="">Read More</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:pac-inner/pac-inner --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->