<?php
/**
 * Title: Pacific 54 Front Page Text
 * Slug: pacific54/pac-frnt-page-text
 * Categories: featured
 */
?>



<!-- wp:column {"className":"col-lg-4 col-md-6 wow zoomIn"} -->
<div class="wp-block-column col-lg-4 col-md-6 wow zoomIn"><!-- wp:pac-inner/pac-inner {"className":"inner-block-white-bg text-center service-item d-flex flex-column justify-content-center text-center rounded"} -->
<div class="wp-block-pac-inner-pac-inner inner-block-white-bg text-center service-item d-flex flex-column justify-content-center rounded"><!-- wp:html -->
        <div class="service-icon flex-shrink-0">
          <i class="fa fa-home fa-2x"></i>
          </div>

<!-- /wp:html -->

<!-- wp:heading {"textAlign":"center","level":5,"style":{"typography":{"textTransform":"capitalize","fontStyle":"normal","fontWeight":"700"}},"className":"mb-3"} -->
<h5 class="wp-block-heading has-text-align-center mb-3" style="font-style:normal;font-weight:700;text-transform:capitalize">SEO Optimization</h5>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"padding":{"top":"0","right":"var:preset|spacing|40","bottom":"0","left":"var:preset|spacing|50"}}}} -->
<p class="has-text-align-center" style="padding-top:0;padding-right:var(--wp--preset--spacing--40);padding-bottom:0;padding-left:var(--wp--preset--spacing--50)">Erat ipsum justo amet duo et elitr dolor, est duo duo eos lorem sed diam stet diam sed stet lorem. <br><a class="btn px-3 mt-auto mx-auto" href="">Read More</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:pac-inner/pac-inner --></div>
<!-- /wp:column -->