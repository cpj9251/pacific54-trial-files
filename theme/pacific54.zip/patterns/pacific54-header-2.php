<?php
/**
 * Title: Pacific 54 header - 2
 * Slug: pacific54/pacific54-header-2
 * Categories: featured
 */
?>

<!-- wp:group {"layout":{"type":"constrained"},"className":"navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0"} -->
<div class="wp-block-group navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">

<!-- wp:heading {"level":1,"className":"m-0"} -->

    <h1 class="m-0">
        <a href="" class="navbar-brand p-0"><i class="fa fa-search me-2"></i>SEO<span class="fs-5">Master</span></a></h1>
<!-- /wp:heading -->

<!-- wp:group {"layout":{"type":"constrained"},"className":"collapse navbar-collapse"} -->
<div class="wp-block-group collapse navbar-collapse" id="navbarCollapse">
 
<!-- wp:navigation {"ref":38} /-->   

<!-- wp:button {"class":"btn btn-secondary text-light rounded-pill py-2 px-4 ms-3"} -->
<a href="https://htmlcodex.com/startup-company-website-template" class="wp-button-block btn btn-secondary text-light rounded-pill py-2 px-4 ms-3">Pro Version</a>
<!-- /wp:button -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

