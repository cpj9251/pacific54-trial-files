<?php
/**
 * Functions and definitions for pacific54 theme
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package WordPress
 * @subpackage pacific54
 * @since pacific54 1.0
 */

 function pacific54_scripts() {
    
    wp_enqueue_style( 'pacific54-style', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) );
    wp_enqueue_style( 'google-fonts', 'https://fonts.googleapis.com/css2?family=Heebo:wght@400;500&family=Roboto:wght@400;500;700&display=swap' );
    wp_enqueue_style( 'cloudflare', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css' );
    wp_enqueue_style( 'bootstrap-icons', 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css' );
    wp_enqueue_style( 'animate-style', get_template_directory_uri() . '/lib/animate/animate.min.css');
    wp_enqueue_style( 'owl-style', get_template_directory_uri() . '/lib/owlcarousel/assets/owl.carousel.min.css');
    wp_enqueue_style( 'lightbox-style', get_template_directory_uri() . '/lib/lightbox/css/lightbox.min.css');
    wp_enqueue_style( 'bootstrap-style', get_template_directory_uri() . '/css/bootstrap.min.css');
    wp_enqueue_style( 'custom-style', get_template_directory_uri() . '/css/style.css');
 	
    //javascript

    wp_enqueue_script('jquery');
    wp_enqueue_script('bootstrap-js','https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js',array(),false,true);
    wp_enqueue_script('wow-js', get_template_directory_uri().'/lib/wow/wow.min.js', array(), false, true);
    wp_enqueue_script('easing-js', get_template_directory_uri().'/lib/easing/easing.min.js', array(), false, true);
    wp_enqueue_script('waypoint-js', get_template_directory_uri().'/lib/waypoints/waypoints.min.js', array(), false, true);
    wp_enqueue_script('owl-js', get_template_directory_uri().'/lib/owlcarousel/owl.carousel.min.js', array(), false, true);
    wp_enqueue_script('isotope-js', get_template_directory_uri().'/lib/isotope/isotope.pkgd.min.js', array(), false, true);
    wp_enqueue_script('lightbox-js', get_template_directory_uri().'/lib/lightbox/js/lightbox.min.js', array(), false, true);
    
    wp_enqueue_script('pacific54-js', get_template_directory_uri().'/js/main.js',array('jquery'),'1.0.0',true);
}

add_action( 'wp_enqueue_scripts', 'pacific54_scripts' );
add_action( 'admin_enqueue_scripts', 'pacific54_scripts' );

function do_theme_setup(){
    add_theme_support('wp-block-styles');
    add_editor_style('editor-styles.css');
}// end fx
add_action('after_setup_theme','do_theme_setup');


function setup_menus(){
        register_nav_menus(
            array(
                'primary' => esc_html__( 'Primary menu', 'twentytwentyone' ),
                'footer'  => esc_html__( 'Secondary menu', 'twentytwentyone' ),
            )
        );
}

add_action( 'after_setup_theme', 'setup_menus' );

add_action('admin_init', function(){

    add_editor_style('editor-style.css');
    add_editor_style('css/bootstrap.min.css');
    add_editor_style('style.css');
});

