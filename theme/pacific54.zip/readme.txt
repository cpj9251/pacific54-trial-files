=== Pacific 54 ===
Contributors: wordpressdotorg
Requires at least: 6.1
Tested up to: 6.2
Requires PHP: 7.0
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Pacific54 template set up for Test.
